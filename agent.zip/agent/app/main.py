import os

from dotenv import load_dotenv

from app.agent import ModularSupportAgent


def main() -> None:
    load_dotenv()
    model_name = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    api_key = os.getenv("OPENAI_API_KEY")

    if not api_key:
        print(
            "Error: falta OPENAI_API_KEY. "
            "Crea un archivo .env (puedes copiar .env.example) y añade tu clave."
        )
        return

    agent = ModularSupportAgent(model_name=model_name)

    print("Agente modular iniciado. Escribe 'salir' para terminar.\n")
    while True:
        user_query = input("Tú: ").strip()
        if user_query.lower() in {"salir", "exit", "quit"}:
            print("Fin de sesión.")
            break

        result = agent.process(user_query)
        print(f"\n[Intención detectada: {result.intent}]")
        print(f"[Resultado tool: {result.tool_result}]")
        print(f"Agente:\n{result.response_text}\n")


if __name__ == "__main__":
    main()
