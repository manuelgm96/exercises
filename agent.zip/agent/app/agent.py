from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from langchain_openai import ChatOpenAI

from app.tools.data_api_tool import data_api_tool
from app.tools.internal_kb_tool import internal_kb_tool
from app.tools.web_search_tool import web_search_tool
from app.utils.chat_history import InMemoryChatHistory
from app.utils.prompts import SYSTEM_PROMPT, build_final_prompt
from app.utils.response_formatter import format_response
from app.utils.router import route_intent


@dataclass
class AgentResult:
    response_text: str
    intent: str
    tool_result: str


class ModularSupportAgent:
    def __init__(self, model_name: str = "gpt-4o-mini", temperature: float = 0.2) -> None:
        self.llm = ChatOpenAI(model=model_name, temperature=temperature)
        self.history = InMemoryChatHistory()

    def _run_tool(self, intent: str, user_query: str) -> str:
        if intent == "kb_interna":
            return internal_kb_tool.invoke(user_query)
        if intent == "busqueda_web":
            return web_search_tool.invoke(user_query)
        if intent == "api_datos":
            return data_api_tool.invoke(user_query)
        return "No se requiere herramienta externa."

    def process(self, user_query: str) -> AgentResult:
        self.history.add_user_message(user_query)

        intent = route_intent(user_query)
        recommendation: Optional[str] = None
        error_note: Optional[str] = None

        try:
            tool_result = self._run_tool(intent, user_query)
        except Exception as exc:  # noqa: BLE001
            tool_result = "No fue posible obtener datos de la herramienta seleccionada."
            error_note = f"Fallo de herramienta: {exc}"
            recommendation = "Reintenta en unos minutos o reformula la consulta."

        final_prompt = build_final_prompt(
            user_query=user_query,
            tool_result=tool_result,
            chat_history=self.history.render(),
        )

        llm_output = self.llm.invoke(
            [
                ("system", SYSTEM_PROMPT),
                ("user", final_prompt),
            ]
        )

        main_answer = getattr(llm_output, "content", str(llm_output))
        final_text = format_response(
            main_answer=main_answer,
            recommendation=recommendation,
            error=error_note,
        )

        self.history.add_assistant_message(final_text)

        return AgentResult(response_text=final_text, intent=intent, tool_result=tool_result)
