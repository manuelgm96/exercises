# Agente modular LangChain (Fase 1)

Implementación base en **Python + LangChain** para procesar consultas, enrutar intención,
usar herramientas modulares y responder de forma coherente.

## Estructura

```
app/
  agent.py
  main.py
  tools/
    internal_kb_tool.py
    web_search_tool.py
    data_api_tool.py
  utils/
    prompts.py
    router.py
    chat_history.py
    response_formatter.py
requirements.txt
.env.example
```

## Requisitos

1. Python 3.10+
2. Variables de entorno:
   - `LLM_PROVIDER` (`openai` u `ollama`)
   - Si `openai`: `OPENAI_API_KEY`, `OPENAI_MODEL`
   - Si `ollama`: `OLLAMA_MODEL`, `OLLAMA_BASE_URL`

## Instalación

```bash
pip install -r requirements.txt
```

## Configuración

1. Copia `.env.example` a `.env`
2. Elige proveedor:
   - **OpenAI**: completa `OPENAI_API_KEY`
   - **Ollama**: asegúrate de tener Ollama levantado y un modelo descargado

### Uso con Ollama

```bash
ollama serve
ollama pull llama3.1:8b
```

En `.env`:

```env
LLM_PROVIDER=ollama
OLLAMA_MODEL=llama3.1:8b
OLLAMA_BASE_URL=http://localhost:11434
```

## Ejecución

```bash
python -m app.main
```

## Qué hace esta Fase 1

- Clasifica intención (`kb_interna`, `busqueda_web`, `api_datos`, `respuesta_directa`)
- Ejecuta una tool modular según intención
- Mantiene histórico de chat **en memoria** durante la sesión
- Genera respuesta final usando prompt del sistema
- Devuelve formato consistente con respuesta + notificaciones opcionales

## Notas

- `web_search_tool` y `data_api_tool` están simuladas para Fase 1.
- En Fase 2 puedes conectar proveedores reales (search/API externa, DB persistente, etc.).
