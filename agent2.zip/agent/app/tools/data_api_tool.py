from langchain_core.tools import tool


@tool
def data_api_tool(query: str) -> str:
    """Consulta una API de datos simulada (clima/finanzas/noticias) para Fase 1."""
    q = query.lower()
    if "clima" in q or "temperatura" in q:
        return "API datos (simulada): 22°C, parcialmente nublado."
    if "finanzas" in q or "bolsa" in q:
        return "API datos (simulada): índice principal +0.8% en la sesión actual."
    if "noticias" in q:
        return "API datos (simulada): titulares del día disponibles, pendiente integración real."
    return "API datos (simulada): no hay datos específicos para esa consulta."
