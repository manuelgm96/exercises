from langchain_core.tools import tool


@tool
def web_search_tool(query: str) -> str:
    """Realiza una búsqueda web simulada para Fase 1."""
    return (
        "Resultado de búsqueda web (simulado): "
        f"Se encontraron fuentes relevantes para: '{query}'. "
        "Integra un proveedor real de búsqueda en Fase 2."
    )
