from langchain_core.tools import tool


@tool
def internal_kb_tool(query: str) -> str:
    """Consulta una base de conocimiento interna simulada."""
    kb = {
        "horario": "El horario de soporte interno es de 9:00 a 18:00 (L-V).",
        "vacaciones": "Las solicitudes de vacaciones se realizan en el portal interno con 7 días de antelación.",
        "acceso": "Para solicitar acceso, abre un ticket al equipo de IT en el sistema interno.",
    }

    q = query.lower()
    for key, value in kb.items():
        if key in q:
            return value
    return "No encontré información exacta en la base interna para esa consulta."
