import os

from dotenv import load_dotenv

from app.agent import ModularSupportAgent


def main() -> None:
    load_dotenv()
    provider = os.getenv("LLM_PROVIDER", "openai").lower().strip()

    if provider == "ollama":
        model_name = os.getenv("OLLAMA_MODEL", "llama3.1:8b")
        ollama_base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        agent = ModularSupportAgent(
            provider="ollama",
            model_name=model_name,
            ollama_base_url=ollama_base_url,
        )
    else:
        model_name = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            print(
                "Error: falta OPENAI_API_KEY. "
                "Crea un archivo .env (puedes copiar .env.example) y añade tu clave."
            )
            return

        agent = ModularSupportAgent(provider="openai", model_name=model_name)

    print("Agente modular iniciado. Escribe 'salir' para terminar.\n")
    while True:
        user_query = input("Tú: ").strip()
        if user_query.lower() in {"salir", "exit", "quit"}:
            print("Fin de sesión.")
            break

        result = agent.process(user_query)
        print(f"\n[Intención detectada: {result.intent}]")
        print(f"[Resultado tool: {result.tool_result}]")
        print(f"Agente:\n{result.response_text}\n")


if __name__ == "__main__":
    main()
