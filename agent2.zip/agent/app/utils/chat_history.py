from typing import List, Dict


class InMemoryChatHistory:
    def __init__(self) -> None:
        self.messages: List[Dict[str, str]] = []

    def add_user_message(self, content: str) -> None:
        self.messages.append({"role": "user", "content": content})

    def add_assistant_message(self, content: str) -> None:
        self.messages.append({"role": "assistant", "content": content})

    def render(self, limit: int = 10) -> str:
        recent = self.messages[-limit:]
        if not recent:
            return "(sin historial previo)"
        return "\n".join([f"{m['role']}: {m['content']}" for m in recent])
