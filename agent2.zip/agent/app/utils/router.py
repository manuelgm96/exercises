from typing import Literal

Intent = Literal["kb_interna", "busqueda_web", "api_datos", "respuesta_directa"]


def route_intent(query: str) -> Intent:
    q = query.lower()

    if any(k in q for k in ["política", "procedimiento", "manual interno", "empresa"]):
        return "kb_interna"

    if any(k in q for k in ["clima", "temperatura", "lluvia", "finanzas", "bolsa", "noticias"]):
        return "api_datos"

    if any(k in q for k in ["buscar", "internet", "web", "actualidad", "últimas"]):
        return "busqueda_web"

    return "respuesta_directa"
