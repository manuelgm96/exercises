from typing import Optional


def format_response(
    main_answer: str,
    recommendation: Optional[str] = None,
    error: Optional[str] = None,
) -> str:
    parts = [f"Respuesta: {main_answer}"]
    if recommendation:
        parts.append(f"Siguientes pasos: {recommendation}")
    if error:
        parts.append(f"Notificación: {error}")
    return "\n".join(parts)
